# ============================================================================
# PROYECTO FINAL DANIEL DEL CID 1009823
# ============================================================================

import streamlit as st
import re
import random
import json
from dataclasses import dataclass
from typing import List, Dict, Tuple, Optional, Set, Iterable
from collections import defaultdict, deque
import graphviz
from io import BytesIO
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image as RLImage, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib.enums import TA_CENTER
import pandas as pd
from datetime import datetime
import networkx as nx

# ============================================================================
# ESTRUCTURAS DE DATOS
# ============================================================================

@dataclass
class Production:
    left: str
    right: str

    def __str__(self):
        arrow = "→"
        r = self.right if self.right not in ["", "ε", "λ"] else "ε"
        return f"{self.left} {arrow} {r}"


@dataclass
class Grammar:
    productions: List[Production]
    start_symbol: str = "S"

    def __str__(self):
        return "\n".join(str(p) for p in self.productions)


@dataclass
class ClassificationResult:
    chomsky_type: int
    type_name: str
    justification: str
    detailed_analysis: List[str]
    violations: List[str]


# ============================================================================
# PARSER DE GRAMÁTICAS (con soporte básico BNF y →/->)
# ============================================================================

class GrammarParser:
    @staticmethod
    def normalize_bnf_line(line: str) -> List[Tuple[str, str]]:
        line = line.strip()
        if not line or line.startswith('#'):
            return []

        def clean_nt(s: str) -> str:
            s = s.strip()
            s = s.replace("⟨", "").replace("⟩", "")
            return s

        if "::=" in line:
            left, right = line.split("::=", 1)
            left = clean_nt(left)
            alts = [a.strip() for a in right.split("|")]
            return [(left, a if a != "" else "ε") for a in alts]

        if "→" in line or "->" in line:
            if "→" in line:
                left, right = line.split("→", 1)
            else:
                left, right = line.split("->", 1)
            left = clean_nt(left)
            alts = [a.strip() for a in right.split("|")]
            return [(left, a if a != "" else "ε") for a in alts]

        return []

    @staticmethod
    def parse(grammar_text: str, start_symbol: str = "S") -> Grammar:
        productions: List[Production] = []
        for raw in grammar_text.strip().split("\n"):
            for (L, R) in GrammarParser.normalize_bnf_line(raw):
                productions.append(Production(L.strip(), R.strip()))
        return Grammar(productions, start_symbol=start_symbol)

    @staticmethod
    def is_terminal(symbol: str) -> bool:
        if not symbol:
            return False
        return symbol == 'ε' or symbol[0].islower() or symbol[0].isdigit() or symbol in ['λ']

    @staticmethod
    def is_variable(symbol: str) -> bool:
        if not symbol:
            return False
        return symbol[0].isupper()

    @staticmethod
    def split_symbols(string: str) -> List[str]:
        if string in ['ε', 'λ', '']:
            return ['ε']
        symbols = []
        i = 0
        while i < len(string):
            ch = string[i]
            if ch.isupper():
                j = i + 1
                while j < len(string) and (string[j].isdigit() or string[j] == "'"):
                    j += 1
                symbols.append(string[i:j])
                i = j
            else:
                symbols.append(ch)
                i += 1
        return symbols


# ============================================================================
# CLASIFICADOR DE GRAMÁTICAS (ε fixes, regular izquierda/derecha)
# ============================================================================

class ChomskyClassifier:
    def __init__(self):
        self.parser = GrammarParser()

    def classify(self, grammar: Grammar) -> ClassificationResult:
        detailed_analysis = []
        violations = []

        # Intentar Tipo 3
        is_type3, d3 = self._check_type3(grammar)
        detailed_analysis.extend(d3)
        if is_type3:
            return ClassificationResult(
                3, "Regular",
                "Todas las producciones cumplen forma lineal (izquierda o derecha) y S→ε solo si S no aparece en RHS.",
                detailed_analysis, violations
            )

        # Intentar Tipo 2
        is_type2, d2 = self._check_type2(grammar)
        detailed_analysis.extend(d2)
        if is_type2:
            return ClassificationResult(
                2, "Libre de Contexto",
                "Cada producción tiene exactamente una variable en el lado izquierdo (A → β).",
                detailed_analysis, violations
            )

        # Intentar Tipo 1
        is_type1, d1 = self._check_type1(grammar)
        detailed_analysis.extend(d1)
        if is_type1:
            return ClassificationResult(
                1, "Sensible al Contexto",
                "Producciones no contractivas (|α| ≤ |β|). S→ε solo si S no aparece en RHS.",
                detailed_analysis, violations
            )

        # Por descarte, Tipo 0
        return ClassificationResult(
            0, "Recursivamente Enumerable",
            "No cumple restricciones de tipos 1, 2 o 3.",
            detailed_analysis, violations
        )

    def _S_in_rhs(self, grammar: Grammar) -> bool:
        S = grammar.start_symbol
        for p in grammar.productions:
            rhs_syms = self.parser.split_symbols(p.right)
            if S in rhs_syms:
                return True
        return False

    def _check_type3(self, grammar: Grammar) -> Tuple[bool, List[str]]:
        details = ["\n**Verificando Tipo 3 (Regular)**"]
        S_in_rhs = self._S_in_rhs(grammar)
        S = grammar.start_symbol
        has_left_linear = False
        has_right_linear = False

        for prod in grammar.productions:
            left_syms = self.parser.split_symbols(prod.left)
            right_syms = self.parser.split_symbols(prod.right)

            if len(left_syms) != 1 or not self.parser.is_variable(left_syms[0]):
                details.append(f"X `{prod}`: LHS debe ser una variable única.")
                return False, details

            if prod.right in ['ε', 'λ', '']:
                if prod.left == S and not S_in_rhs:
                    details.append(f" BIEEN `{prod}`: S→ε permitido y S no aparece en RHS.")
                    continue
                else:
                    details.append(f"X `{prod}`: ε solo permitido como S→ε y si S no aparece en RHS.")
                    return False, details

            right_linear = (
                (len(right_syms) == 1 and self.parser.is_terminal(right_syms[0])) or
                (len(right_syms) == 2 and self.parser.is_terminal(right_syms[0]) and self.parser.is_variable(right_syms[1]))
            )
            left_linear = (
                (len(right_syms) == 1 and self.parser.is_terminal(right_syms[0])) or
                (len(right_syms) == 2 and self.parser.is_variable(right_syms[0]) and self.parser.is_terminal(right_syms[1]))
            )

            if right_linear:
                has_right_linear = True
            if left_linear:
                has_left_linear = True

            if not (right_linear or left_linear):
                details.append(f"X `{prod}`: No es forma regular (esperado a|aB o Ba).")
                return False, details

        if has_left_linear and has_right_linear:
            details.append("X Mezcla de regular por la izquierda y derecha.")
            return False, details

        details.append("**Todas las producciones cumplen una forma regular consistente.**")
        return True, details

    def _check_type2(self, grammar: Grammar) -> Tuple[bool, List[str]]:
        details = ["\n**Verificando Tipo 2 (Libre de Contexto)**"]
        for prod in grammar.productions:
            left_syms = self.parser.split_symbols(prod.left)
            if len(left_syms) != 1 or not self.parser.is_variable(left_syms[0]):
                details.append(f"X `{prod}`: LHS no es exactamente una variable.")
                return False, details
            details.append(f" BIEEN `{prod}`: Forma A → β válida.")
        details.append("**Todas las producciones tienen forma libre de contexto.**")
        return True, details

    def _check_type1(self, grammar: Grammar) -> Tuple[bool, List[str]]:
        details = ["\n**Verificando Tipo 1 (Sensible al Contexto)**"]
        S_in_rhs = self._S_in_rhs(grammar)
        S = grammar.start_symbol

        for prod in grammar.productions:
            if prod.right in ['ε', 'λ', '']:
                if prod.left == S and not S_in_rhs:
                    details.append(f" BIEEN `{prod}`: S→ε permitido en Tipo 1 (S no en RHS).")
                    continue
                else:
                    details.append(f"X `{prod}`: ε no permitido salvo S→ε y S fuera de RHS.")
                    return False, details

            l = len(self.parser.split_symbols(prod.left))
            r = len(self.parser.split_symbols(prod.right))
            if l > r:
                details.append(f"X `{prod}`: Contractiva |{prod.left}|={l} > |{prod.right}|={r}.")
                return False, details
            details.append(f" BIEEN `{prod}`: No contractiva |α|={l} ≤ |β|={r}.")

        details.append("**Todas las producciones son no contractivas.**")
        return True, details


# ============================================================================
# VISUALIZADOR
# ============================================================================

class GrammarVisualizer:
    @staticmethod
    def create_grammar_graph(grammar: Grammar, result: ClassificationResult) -> graphviz.Digraph:
        dot = graphviz.Digraph(comment='Grammar Visualization')
        dot.attr(rankdir='LR')

        colors = {0: '#ff6b6b', 1: '#ffd93d', 2: '#6bcf7f', 3: '#4ecdc4'}
        color = colors.get(result.chomsky_type, '#95a5a6')

        variables = sorted({p.left for p in grammar.productions})
        S = grammar.start_symbol
        for var in variables:
            shape = 'doublecircle' if var == S else 'circle'
            dot.node(var, var, shape=shape, style='filled', fillcolor=color)

        final_node = "END"
        dot.node(final_node, final_node, shape='doublecircle', style='dashed')

        for prod in grammar.productions:
            lhs = prod.left
            rhs_syms = GrammarParser.split_symbols(prod.right)
            if prod.right in ['ε', 'λ', '']:
                dot.edge(lhs, final_node, label='ε')
            elif len(rhs_syms) == 2:
                if GrammarParser.is_terminal(rhs_syms[0]) and GrammarParser.is_variable(rhs_syms[1]):
                    dot.edge(lhs, rhs_syms[1], label=rhs_syms[0])
                elif GrammarParser.is_variable(rhs_syms[0]) and GrammarParser.is_terminal(rhs_syms[1]):
                    dot.edge(lhs, rhs_syms[0], label=rhs_syms[1])
            elif len(rhs_syms) == 1 and GrammarParser.is_terminal(rhs_syms[0]):
                dot.edge(lhs, final_node, label=rhs_syms[0])
            else:
                dot.edge(lhs, lhs, label=prod.right, style='dotted')

        return dot

    @staticmethod
    def create_automaton_dfa(transitions: Dict[str, Dict[str, str]], initial: str, finals: Set[str]) -> graphviz.Digraph:
        dot = graphviz.Digraph(comment='DFA')
        dot.attr(rankdir='LR')
        dot.node('start', '', shape='none')
        states = set(transitions.keys())
        for s in states | set(finals) | {initial}:
            shape = 'doublecircle' if s in finals else 'circle'
            dot.node(s, s, shape=shape)
        dot.edge('start', initial)
        for s, trans in transitions.items():
            for a, nxt in trans.items():
                dot.edge(s, nxt, label=a)
        return dot

    @staticmethod
    def create_pda_graph(pda: Dict) -> graphviz.Digraph:
        dot = graphviz.Digraph(comment='PDA')
        dot.attr(rankdir='LR')
        dot.node('start', '', shape='none')
        for s in pda["states"]:
            shape = 'doublecircle' if s in set(pda.get("final_states", [])) else 'circle'
            dot.node(s, s, shape=shape)
        dot.edge('start', pda["start_state"])
        for t in pda["transitions"]:
            lab = f"{t.get('read','ε')}, {t.get('pop','ε')} → {t.get('push','ε') or 'ε'}"
            dot.edge(t["from"], t["to"], label=lab)
        return dot


# ============================================================================
# ÁRBOLES DE DERIVACIÓN (NetworkX + Graphviz)
# ============================================================================

class DerivationTreeBuilder:
    @staticmethod
    def build_leftmost_derivation_tree(
        grammar: Grammar,
        target: str,
        max_steps: int = 10,
        max_nodes: int = 1000
    ) -> Tuple[nx.DiGraph, Optional[int]]:
        """
        Construye un árbol de derivación basado en derivaciones izquierdas
        de sentencias completas, usando NetworkX.

        Cada nodo representa una forma sentencial y cada arista una producción
        aplicada. Si se encuentra la cadena objetivo, se devuelve el id del nodo
        que la contiene para destacarlo en el gráfico.
        """
        G = nx.DiGraph()
        root_label = grammar.start_symbol
        G.add_node(0, label=root_label)

        prods_by_L = defaultdict(list)
        for p in grammar.productions:
            prods_by_L[p.left].append(p.right)

        queue = deque([(root_label, 0, 0)])
        success_node: Optional[int] = None

        while queue:
            sentential, node_id, depth = queue.popleft()
            if depth > max_steps:
                continue

            if sentential == target:
                success_node = node_id
                break

            # Encontrar la primera variable (derivación izquierda)
            i = 0
            while i < len(sentential) and not sentential[i].isupper():
                i += 1
            if i == len(sentential):
                continue
            j = i + 1
            while j < len(sentential) and (sentential[j].isdigit() or sentential[j] == "'"):
                j += 1
            LHS = sentential[i:j]
            prefix = sentential[:i]
            suffix = sentential[j:]

            for rhs in prods_by_L.get(LHS, []):
                rep = rhs if rhs not in ['ε', 'λ', ''] else ''
                new_sentential = prefix + rep + suffix
                if len(new_sentential.replace('ε', '')) > len(target) + 2:
                    continue

                new_id = len(G.nodes)
                if new_id >= max_nodes:
                    return G, success_node

                G.add_node(new_id, label=new_sentential)
                edge_label = f"{LHS}→{rhs if rhs not in ['','ε','λ'] else 'ε'}"
                G.add_edge(node_id, new_id, label=edge_label)
                queue.append((new_sentential, new_id, depth + 1))

        return G, success_node


class DerivationTreeVisualizer:
    @staticmethod
    def nx_to_graphviz(G: nx.DiGraph, highlight_node: Optional[int] = None) -> graphviz.Digraph:
        dot = graphviz.Diagraph(comment="Derivation Tree") if False else graphviz.Digraph(comment="Derivation Tree")
        dot.attr(rankdir='TB')
        for n, data in G.nodes(data=True):
            label = data.get('label', str(n))
            if highlight_node is not None and n == highlight_node:
                dot.node(str(n), label, shape='doublecircle', style='filled', fillcolor='#4ecdc4')
            else:
                dot.node(str(n), label, shape='circle')
        for u, v, data in G.edges(data=True):
            lab = data.get('label', '')
            dot.edge(str(u), str(v), label=lab)
        return dot


# ============================================================================
# GENERADOR DE EJEMPLOS
# ============================================================================

class ExampleGenerator:
    @staticmethod
    def generate_type3() -> str:
        patterns = [
            "S → aA\nA → bB\nB → a\nB → b",
            "S → 0S\nS → 1A\nA → 0\nA → 1",
            "S → aS | bA\nA → a | b",
            "S → xY\nY → yZ\nZ → z | ε"
        ]
        return random.choice(patterns)

    @staticmethod
    def generate_type2() -> str:
        patterns = [
            "S → aSb | ab",
            "S → aSa | bSb | a | b",
            "S → aAB\nA → bA | b\nB → cB | c",
            "S → AB\nA → aA | a\nB → bB | b"
        ]
        return random.choice(patterns)

    @staticmethod
    def generate_type1() -> str:
        patterns = [
            "S → aSBC | aBC\nCB → BC\naB → ab\nbB → bb\nbC → bc\ncC → cc",
            "S → abc | aAbc\nAb → bA\nAc → Bbcc\nbB → Bb\naB → aa | aaA",
            "AB → BA\nS → ABS | AB"
        ]
        return random.choice(patterns)

    @staticmethod
    def generate_type0() -> str:
        patterns = [
            "S → aSb | AB\nBA → ε\nAB → a",
            "S → AB | BA\nAB → ε\nBA → ε",
            "S → aAb\nAb → bA\nA → ε"
        ]
        return random.choice(patterns)


# ============================================================================
# REGEX → AFN (Thompson) → AFD (subconjuntos) → Gramática Regular
#    + AFD → Regex (viceversa)
# ============================================================================

def _regex_tokenize(regex: str) -> List[str]:
    tokens = []
    i = 0
    while i < len(regex):
        c = regex[i]
        if c in {'(', ')', '|', '*'}:
            tokens.append(c)
            i += 1
        elif c.isspace():
            i += 1
        else:
            tokens.append(c)
            i += 1
    output = []
    for j, t in enumerate(tokens):
        output.append(t)
        if j < len(tokens) - 1:
            a, b = t, tokens[j + 1]
            if (a not in {'(', '|'} and b not in {')', '|', '*'}) or (a == ')' and b not in {'|', ')', '*'}):
                output.append('.')
    return output


def _to_postfix(tokens: List[str]) -> List[str]:
    prec = {'*': 3, '.': 2, '|': 1}
    out = []
    stack = []
    for t in tokens:
        if t not in {'|', '.', '*', '(', ')'}:
            out.append(t)
        elif t == '(':
            stack.append(t)
        elif t == ')':
            while stack and stack[-1] != '(':
                out.append(stack.pop())
            if stack:
                stack.pop()
        elif t == '*':
            out.append(t)
        else:
            while stack and stack[-1] != '(' and prec.get(stack[-1], 0) >= prec[t]:
                out.append(stack.pop())
            stack.append(t)
    while stack:
        out.append(stack.pop())
    return out


@dataclass
class AFN:
    start: int
    finals: Set[int]
    transitions: Dict[int, Dict[str, Set[int]]]


@dataclass
class AFD:
    start: str
    finals: Set[str]
    transitions: Dict[str, Dict[str, str]]


def _new_state(counter=[0]):
    counter[0] += 1
    return counter[0]


def _epsilon_closure(states: Set[int], trans: Dict[int, Dict[str, Set[int]]]) -> Set[int]:
    stack = list(states)
    closure = set(states)
    while stack:
        s = stack.pop()
        for nxt in trans.get(s, {}).get('ε', set()):
            if nxt not in closure:
                closure.add(nxt)
                stack.append(nxt)
    return closure


def _move(states: Set[int], symbol: str, trans: Dict[int, Dict[str, Set[int]]]) -> Set[int]:
    out = set()
    for s in states:
        out |= trans.get(s, {}).get(symbol, set())
    return out


def regex_to_afn(regex: str) -> AFN:
    tokens = _regex_tokenize(regex)
    post = _to_postfix(tokens)

    stack: List[AFN] = []

    def lit(c: str) -> AFN:
        s = _new_state()
        f = _new_state()
        trans = defaultdict(lambda: defaultdict(set))
        trans[s][c].add(f)
        return AFN(s, {f}, trans)

    for t in post:
        if t not in {'|', '.', '*'}:
            stack.append(lit(t))
        elif t == '*':
            nfa = stack.pop()
            s = _new_state()
            f = _new_state()
            trans = defaultdict(lambda: defaultdict(set))
            for p, m in nfa.transitions.items():
                for a, dests in m.items():
                    trans[p][a] |= set(dests)
            trans[s]['ε'].add(nfa.start)
            trans[s]['ε'].add(f)
            for ff in nfa.finals:
                trans[ff]['ε'].add(nfa.start)
                trans[ff]['ε'].add(f)
            stack.append(AFN(s, {f}, trans))
        elif t == '.':
            n2 = stack.pop()
            n1 = stack.pop()
            trans = defaultdict(lambda: defaultdict(set))
            for p, m in n1.transitions.items():
                for a, dests in m.items():
                    trans[p][a] |= set(dests)
            for p, m in n2.transitions.items():
                for a, dests in m.items():
                    trans[p][a] |= set(dests)
            for f1 in n1.finals:
                trans[f1]['ε'].add(n2.start)
            stack.append(AFN(n1.start, set(n2.finals), trans))
        elif t == '|':
            n2 = stack.pop()
            n1 = stack.pop()
            s = _new_state()
            f = _new_state()
            trans = defaultdict(lambda: defaultdict(set))
            for p, m in n1.transitions.items():
                for a, dests in m.items():
                    trans[p][a] |= set(dests)
            for p, m in n2.transitions.items():
                for a, dests in m.items():
                    trans[p][a] |= set(dests)
            trans[s]['ε'].add(n1.start)
            trans[s]['ε'].add(n2.start)
            for f1 in n1.finals:
                trans[f1]['ε'].add(f)
            for f2 in n2.finals:
                trans[f2]['ε'].add(f)
            stack.append(AFN(s, {f}, trans))

    assert len(stack) == 1, "Regex mal formado"
    return stack[0]


def afn_to_afd(nfa: AFN, alphabet: Optional[Iterable[str]] = None) -> AFD:
    if alphabet is None:
        sset = set()
        for _, m in nfa.transitions.items():
            for a in m.keys():
                if a != 'ε':
                    sset.add(a)
        alphabet = sorted(sset)

    start_set = _epsilon_closure({nfa.start}, nfa.transitions)
    start_name = "{" + ",".join(map(str, sorted(start_set))) + "}"
    queue = deque([start_set])
    name_of = {tuple(sorted(start_set)): start_name}
    finals: Set[str] = set()
    trans: Dict[str, Dict[str, str]] = {}
    seen = {tuple(sorted(start_set))}

    while queue:
        S = queue.popleft()
        Sname = name_of[tuple(sorted(S))]
        trans.setdefault(Sname, {})
        if any(s in nfa.finals for s in S):
            finals.add(Sname)
        for a in alphabet:
            U = _epsilon_closure(_move(S, a, nfa.transitions), nfa.transitions)
            if not U:
                continue
            key = tuple(sorted(U))
            if key not in seen:
                seen.add(key)
                name_of[key] = "{" + ",".join(map(str, sorted(U))) + "}"
                queue.append(U)
            trans[Sname][a] = name_of[key]

    return AFD(start=start_name, finals=finals, transitions=trans)


def afd_to_regular_grammar(afd: AFD) -> Grammar:
    def N(q: str) -> str:
        return "Q" + re.sub(r'[^A-Za-z0-9]', '', q)

    prods: List[Production] = []
    for q, m in afd.transitions.items():
        for a, p in m.items():
            prods.append(Production(N(q), a + N(p)))
        if q in afd.finals:
            for a in set(sym for sym in afd.transitions.get(q, {}).keys()):
                prods.append(Production(N(q), a))
            prods.append(Production(N(q), "ε"))
    return Grammar(prods, start_symbol=N(afd.start))


# ---- AFD → Regex (viceversa) ------------------------------------------------

def _re_union(r1: str, r2: str) -> str:
    if not r1:
        return r2
    if not r2:
        return r1
    if r1 == r2:
        return r1
    return f"({r1}|{r2})"


def _re_concat(r1: str, r2: str) -> str:
    if not r1:
        return r2
    if not r2:
        return r1
    if r1 == 'ε':
        return r2
    if r2 == 'ε':
        return r1
    return f"{r1}{r2}"


def _re_star(r: str) -> str:
    if not r or r == 'ε':
        return 'ε'
    return f"({r})*"


def dfa_to_regex(dfa: AFD) -> str:
    """
    Conversión de AFD a expresión regular usando eliminación de estados.
    Implementación básica, suficiente para demostrar el 'viceversa' del enunciado.
    """
    states = set(dfa.transitions.keys()) | {dfa.start} | set(dfa.finals)
    states = list(states)

    qs = "__start__"
    qf = "__final__"

    R: Dict[str, Dict[str, str]] = defaultdict(lambda: defaultdict(str))
    all_states: Set[str] = set(states) | {qs, qf}

    # Transiciones originales
    for p in states:
        for a, q in dfa.transitions.get(p, {}).items():
            R[p][q] = _re_union(R[p][q], a)

    # Epsilon desde nuevo inicio y hacia nuevo final
    R[qs][dfa.start] = _re_union(R[qs][dfa.start], 'ε')
    for f in dfa.finals:
        R[f][qf] = _re_union(R[f][qf], 'ε')

    # Eliminar estados intermedios
    elim_states = [s for s in all_states if s not in {qs, qf}]

    for k in elim_states:
        for i in all_states:
            if i == k:
                continue
            for j in all_states:
                if j == k:
                    continue
                rik = R[i].get(k, "")
                rkk = R[k].get(k, "")
                rkj = R[k].get(j, "")
                rij = R[i].get(j, "")
                if not rik or not rkj:
                    continue
                loop = _re_star(rkk) if rkk else ''
                candidate = _re_concat(rik, _re_concat(loop, rkj))
                R[i][j] = _re_union(rij, candidate)

        # Limpieza opcional (no estrictamente necesaria)
        if k in R:
            del R[k]
        for i in list(R.keys()):
            if k in R[i]:
                del R[i][k]

    final_regex = R[qs].get(qf, "")
    return final_regex if final_regex else "∅"


# ============================================================================
# CFG → PDA (aceptación por pila vacía)
# ============================================================================

def cfg_to_pda(grammar: Grammar) -> Dict:
    vars_ = sorted({p.left for p in grammar.productions})
    terms: Set[str] = set()
    for p in grammar.productions:
        for s in GrammarParser.split_symbols(p.right):
            if GrammarParser.is_terminal(s) and s != 'ε':
                terms.add(s)
    terms = sorted(terms)

    q = "q"
    Z0 = "Z"
    S = grammar.start_symbol
    states = [q]
    stack_alphabet = sorted(set(vars_) | set(terms) | {Z0})
    transitions = []

    transitions.append({"from": q, "to": q, "read": "ε", "pop": Z0, "push": S + Z0})
    for p in grammar.productions:
        A = p.left
        alpha = p.right if p.right not in {'ε', 'λ', ''} else ''
        transitions.append({"from": q, "to": q, "read": "ε", "pop": A, "push": alpha})
    for a in terms:
        transitions.append({"from": q, "to": q, "read": a, "pop": a, "push": ""})
    transitions.append({"from": q, "to": q, "read": "ε", "pop": Z0, "push": ""})

    pda = {
        "states": states,
        "input_alphabet": terms,
        "stack_alphabet": stack_alphabet,
        "start_state": q,
        "start_stack_symbol": Z0,
        "transitions": transitions,
        "final_states": []
    }
    return pda


# ============================================================================
# REPORTES PDF
# ============================================================================

class PDFReportGenerator:
    @staticmethod
    def generate_report(grammar: Grammar, result: ClassificationResult, graph_image: bytes) -> bytes:
        buffer = BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=letter)
        story = []
        styles = getSampleStyleSheet()

        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=24,
            textColor='#2c3e50',
            spaceAfter=30,
            alignment=TA_CENTER
        )

        story.append(Paragraph("Chomsky Classifier AI", title_style))
        story.append(Paragraph("Reporte de Análisis de Gramática", styles['Heading2']))
        story.append(Spacer(1, 0.2 * inch))

        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        story.append(Paragraph(f"Fecha y hora del análisis: {now_str}", styles['Normal']))
        story.append(Spacer(1, 0.3 * inch))

        story.append(Paragraph("<b>Gramática Analizada:</b>", styles['Heading3']))
        grammar_text = str(grammar).replace('\n', '<br/>')
        story.append(Paragraph(grammar_text, styles['Code']))
        story.append(Spacer(1, 0.2 * inch))

        type_colors = {0: '#ff6b6b', 1: '#ffd93d', 2: '#6bcf7f', 3: '#4ecdc4'}
        color = type_colors.get(result.chomsky_type, '#95a5a6')
        result_text = f"<font color='{color}'><b>Tipo {result.chomsky_type}: {result.type_name}</b></font>"
        story.append(Paragraph("<b>Clasificación:</b>", styles['Heading3']))
        story.append(Paragraph(result_text, styles['Normal']))
        story.append(Spacer(1, 0.2 * inch))

        story.append(Paragraph("<b>Justificación:</b>", styles['Heading3']))
        story.append(Paragraph(result.justification, styles['Normal']))
        story.append(Spacer(1, 0.3 * inch))

        story.append(Paragraph("<b>Análisis Detallado:</b>", styles['Heading3']))
        for detail in result.detailed_analysis:
            d = detail.replace('**', '<b>').replace('**', '</b>').replace('`', '<i>').replace('`', '</i>')
            story.append(Paragraph(d, styles['Normal']))

        story.append(PageBreak())

        if graph_image:
            story.append(Paragraph("<b>Diagrama Visual:</b>", styles['Heading3']))
            story.append(Spacer(1, 0.2 * inch))
            img = RLImage(BytesIO(graph_image), width=400, height=300)
            story.append(img)

        story.append(Spacer(1, 0.3 * inch))
        story.append(Paragraph("Reporte generado automáticamente por Chomsky Classifier AI.", styles['Italic']))

        doc.build(story)
        buffer.seek(0)
        return buffer.getvalue()


# ============================================================================
# QUIZ
# ============================================================================

class QuizMode:
    def __init__(self):
        self.generator = ExampleGenerator()
        self.classifier = ChomskyClassifier()

    def generate_question(self) -> Tuple[str, int]:
        t = random.randint(0, 3)
        if t == 3:
            g = self.generator.generate_type3()
        elif t == 2:
            g = self.generator.generate_type2()
        elif t == 1:
            g = self.generator.generate_type1()
        else:
            g = self.generator.generate_type0()
        return g, t

    def check_answer(self, grammar_text: str, user_answer: int, start_symbol: str) -> Tuple[bool, str, ClassificationResult]:
        grammar = GrammarParser.parse(grammar_text, start_symbol=start_symbol)
        result = self.classifier.classify(grammar)
        ok = (user_answer == result.chomsky_type)
        fb = (
            f" BIEEN ¡Correcto! Es Tipo {result.chomsky_type}: {result.type_name}"
            if ok
            else f"X Incorrecto. La respuesta correcta es Tipo {result.chomsky_type}: {result.type_name}"
        )
        return ok, fb, result


# ============================================================================
# GENERACIÓN DE CADENAS Y COMPARADOR
# ============================================================================

def generate_strings(grammar: Grammar, max_len: int, max_nodes: int = 5000) -> Set[str]:
    prods_by_L = defaultdict(list)
    for p in grammar.productions:
        prods_by_L[p.left].append(p.right)

    start = grammar.start_symbol
    start_form = start
    visited = set([start_form])
    q = deque([start_form])
    results: Set[str] = set()

    def is_all_terminal(s: str) -> bool:
        return all((not ch.isupper()) for ch in s) or s == 'ε'

    nodes = 0
    while q:
        cur = q.popleft()
        nodes += 1
        if nodes > max_nodes:
            break
        term_len = 0 if cur in ['ε', 'λ', ''] else sum(1 for c in cur if c.islower() or c.isdigit())
        if is_all_terminal(cur):
            if (cur == 'ε') or (len(cur) <= max_len):
                results.add("" if cur in ['ε', 'λ'] else cur)
            continue
        if term_len > max_len + 2:
            continue
        i = 0
        while i < len(cur) and not cur[i].isupper():
            i += 1
        if i == len(cur):
            continue
        V = cur[i]
        j = i + 1
        while j < len(cur) and (cur[j].isdigit() or cur[j] == "'"):
            j += 1
        LHS = cur[i:j]
        prefixes = cur[:i]
        suffixes = cur[j:]
        for rhs in prods_by_L.get(LHS, []):
            rep = rhs if rhs not in ['ε', 'λ', ''] else ''
            nxt = prefixes + rep + suffixes
            approx_len = sum(1 for c in nxt if c.islower() or c.isdigit())
            if approx_len <= max_len + 2 and nxt not in visited:
                visited.add(nxt)
                q.append(nxt)
    return results


def compare_grammars(g1: Grammar, g2: Grammar, n: int, cap: int = 5000) -> Tuple[Set[str], Set[str], Set[str]]:
    L1 = generate_strings(g1, n, cap)
    L2 = generate_strings(g2, n, cap)
    return L1 & L2, L1 - L2, L2 - L1


# ============================================================================
# AUTÓMATAS: Ingesta/validación y clasificación
# ============================================================================

def classify_automaton_json(txt: str) -> Tuple[int, str, Optional[graphviz.Digraph], str]:
    try:
        data = json.loads(txt)
    except Exception as e:
        return 0, "Recursivamente Enumerable", None, f"JSON inválido: {e}"

    afd_keys = {"states", "alphabet", "start", "accepting", "transitions"}
    if afd_keys.issubset(data.keys()):
        states = set(data["states"])
        if data["start"] not in states:
            return 0, "Recursivamente Enumerable", None, "AFD inválido: start no está en states."
        try:
            for s, m in data["transitions"].items():
                if s not in states:
                    return 0, "Recursivamente Enumerable", None, f"AFD inválido: transición desde estado desconocido {s}."
                for a, t in m.items():
                    if a not in data["alphabet"]:
                        return 0, "Recursivamente Enumerable", None, f"AFD inválido: símbolo {a} fuera del alfabeto."
                    if t not in states:
                        return 0, "Recursivamente Enumerable", None, f"AFD inválido: estado destino {t} no declarado."
            dot = GrammarVisualizer.create_automaton_dfa(data["transitions"], data["start"], set(data["accepting"]))
            return 3, "Regular (AFD)", dot, "AFD válido detectado."
        except Exception as e:
            return 0, "Recursivamente Enumerable", None, f"AFD: error leyendo transiciones: {e}"

    if "stack_alphabet" in data and "transitions" in data and "start_state" in data:
        ok = True
        for t in data["transitions"]:
            for k in ["from", "to", "read", "pop", "push"]:
                if k not in t:
                    ok = False
        if not ok:
            return 2, "Libre de Contexto (AP)", None, "AP detectado pero transiciones incompletas."
        try:
            dot = GrammarVisualizer.create_pda_graph(data)
            return 2, "Libre de Contexto (AP)", dot, "AP detectado."
        except Exception as e:
            return 2, "Libre de Contexto (AP)", None, f"AP detectado, pero no se pudo dibujar: {e}"

    if "delta" in data or "moves" in data or "tape_alphabet" in data:
        if data.get("bounded", False):
            return 1, "Sensible al Contexto (LBA)", None, "Máquina de Turing acotada (LBA) detectada."
        return 0, "Recursivamente Enumerable (MT)", None, "Máquina de Turing general detectada."

    return 0, "Recursivamente Enumerable", None, "No se reconoció estructura; por defecto Tipo 0."


# ============================================================================
# UI STREAMLIT
# ============================================================================

def main():
    st.set_page_config(page_title="Chomsky Classifier AI", page_icon="AI", layout="wide")
    st.markdown("""
    <style>
    .main-title {
        text-align: center;
        color: #2c3e50;
        padding: 20px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        border-radius: 10px;
        color: white;
    }
    .type-box { padding: 14px; border-radius: 10px; margin: 10px 0; font-weight: bold; text-align: center; }
    .type-0 { background-color: #ff6b6b; color: white; }
    .type-1 { background-color: #ffd93d; color: #2c3e50; }
    .type-2 { background-color: #6bcf7f; color: white; }
    .type-3 { background-color: #4ecdc4; color: white; }
    </style>
    """, unsafe_allow_html=True)

    st.markdown('<h1 class="main-title">Chomsky Classifier AI</h1>', unsafe_allow_html=True)
    st.markdown("### Clasificación y conversión entre gramáticas, autómatas y regex (DANIEL DEL CID 100923)")

    if 'quiz_mode' not in st.session_state:
        st.session_state.quiz_mode = False
    if 'quiz_score' not in st.session_state:
        st.session_state.quiz_score = 0
    if 'quiz_total' not in st.session_state:
        st.session_state.quiz_total = 0

    st.sidebar.title("Menú")
    mode = st.sidebar.radio(
        "Selecciona un modo:",
        [
            "Clasificador",
            "Ejemplos",
            "Quiz",
            "Convertidor Regex/AFN/AFD",
            "Comparar",
            "CFG→PDA",
            "AFD→Gramática",
            "Autómatas JSON",
            "Árbol de derivación",
            "Info"
        ]
    )

    # ---------------- Clasificador ----------------
    if mode == "Clasificador":
        st.header("Clasificador de Gramáticas")
        col1, col2 = st.columns([2, 1])
        with col1:
            st.subheader("Ingresa tu gramática")
            start_symbol = st.text_input("Símbolo inicial:", value="S", max_chars=10)
            grammar_input = st.text_area(
                "Formato: A → β (o BNF ⟨A⟩ ::= α | β)",
                height=220,
                value="S → aSb\nS → ab",
                help="Soporta → / -> y BNF ::= , con o sin ⟨ ⟩."
            )
            c1, c2, c3 = st.columns([1, 1, 1])
            with c1:
                classify_btn = st.button("Clasificar", type="primary", use_container_width=True)
            with c2:
                pdf_btn = st.button("Generar Reporte PDF", use_container_width=True)

            if classify_btn:
                try:
                    parser = GrammarParser()
                    classifier = ChomskyClassifier()
                    visualizer = GrammarVisualizer()
                    grammar = parser.parse(grammar_input, start_symbol=start_symbol.strip() or "S")
                    result = classifier.classify(grammar)

                    st.markdown(
                        f'<div class="type-box type-{result.chomsky_type}">'
                        f'Tipo {result.chomsky_type}: {result.type_name}</div>',
                        unsafe_allow_html=True
                    )
                    st.success(result.justification)
                    with st.expander("Ver análisis detallado", expanded=False):
                        for detail in result.detailed_analysis:
                            st.markdown(detail)

                    st.subheader("Visualización")
                    try:
                        graph = visualizer.create_grammar_graph(grammar, result)
                        st.graphviz_chart(graph)
                        graph_png = graph.pipe(format='png')
                        graph_svg = graph.pipe(format='svg')
                        st.session_state['last_graph_png'] = graph_png
                        st.session_state['last_graph_svg'] = graph_svg
                        st.session_state['last_grammar'] = grammar
                        st.session_state['last_result'] = result
                        colg1, colg2 = st.columns(2)
                        with colg1:
                            st.download_button(
                                "Descargar PNG",
                                data=graph_png,
                                file_name="gramatica.png",
                                mime="image/png"
                            )
                        with colg2:
                            st.download_button(
                                "Descargar SVG",
                                data=graph_svg,
                                file_name="gramatica.svg",
                                mime="image/svg+xml"
                            )
                    except Exception as e:
                        st.warning(f"No se pudo generar el diagrama: {e}")
                except Exception as e:
                    st.error(f"Error al procesar: {e}")

            if pdf_btn:
                try:
                    if 'last_result' in st.session_state:
                        pdf_gen = PDFReportGenerator()
                        graph_img = st.session_state.get('last_graph_png', b'')
                        pdf_bytes = pdf_gen.generate_report(
                            st.session_state['last_grammar'],
                            st.session_state['last_result'],
                            graph_img
                        )
                        st.download_button(
                            "Descargar PDF",
                            data=pdf_bytes,
                            file_name="reporte_chomsky.pdf",
                            mime="application/pdf"
                        )
                    else:
                        st.warning("Primero clasifica una gramática")
                except Exception as e:
                    st.error(f"Error al generar PDF: {e}")

        with col2:
            st.subheader("Guía Rápida")
            st.info("""
**Tipo 3 (Regular):**
- A → a, A → aB (o Ba);
- S → ε permitido solo si S no aparece en RHS.

**Tipo 2 (Libre de Contexto):** A → β

**Tipo 1 (Sensible al Contexto):** |α| ≤ |β|, S → ε con la misma condición.

**Tipo 0 (Rec. Enumerable):** Sin restricciones.
""")

    # ---------------- Ejemplos ----------------
    elif mode == "Ejemplos":
        st.header("Generador de Ejemplos")
        col1, col2, col3, col4 = st.columns(4)
        gen = ExampleGenerator()
        with col1:
            if st.button("Tipo 3\n(Regular)", use_container_width=True):
                st.code(gen.generate_type3(), language="text")
        with col2:
            if st.button("Tipo 2\n(Libre de Contexto)", use_container_width=True):
                st.code(gen.generate_type2(), language="text")
        with col3:
            if st.button("Tipo 1\n(Sensible al Contexto)", use_container_width=True):
                st.code(gen.generate_type1(), language="text")
        with col4:
            if st.button("Tipo 0\n(Rec. Enumerable)", use_container_width=True):
                st.code(gen.generate_type0(), language="text")

        st.divider()
        st.subheader("Ejemplos Clásicos")
        examples = {
            "a^n b^n (Tipo 2)": "S → aSb | ab",
            "a^n b^n c^n (Tipo 1)": "S → aSBC | aBC\nCB → BC\naB → ab\nbB → bb\nbC → bc\ncC → cc",
            "Palíndromo (Tipo 2)": "S → aSa | bSb | a | b | ε",
            "Lenguaje Regular (Tipo 3)": "S → aS | bA\nA → aA | b"
        }
        for name, g in examples.items():
            with st.expander(name):
                st.code(g, language="text")
                if st.button(f"Clasificar este ejemplo", key=f"classify_{name}"):
                    try:
                        gg = GrammarParser.parse(g, start_symbol="S")
                        res = ChomskyClassifier().classify(gg)
                        st.markdown(
                            f'<div class="type-box type-{res.chomsky_type}">'
                            f'Tipo {res.chomsky_type}: {res.type_name}</div>',
                            unsafe_allow_html=True
                        )
                        st.info(res.justification)
                    except Exception as e:
                        st.error(f"Error: {e}")

    # ---------------- Quiz ----------------
    elif mode == "Quiz":
        st.header("Modo Tutor Interactivo")
        quiz = QuizMode()
        col1, col2 = st.columns([3, 1])
        with col2:
            st.metric("Puntuación", f"{st.session_state.quiz_score}/{st.session_state.quiz_total}")
            if st.session_state.quiz_total > 0:
                try:
                    percentage = (st.session_state.quiz_score / st.session_state.quiz_total) * 100
                    st.progress(percentage / 100)
                    st.write(f"{percentage:.1f}% correcto")
                except Exception as e:
                    st.warning(f"No se pudo calcular porcentaje: {e}")
        with col1:
            start_symbol = st.text_input(
                "Símbolo inicial (para el ejercicio actual):",
                value="S",
                max_chars=10
            )
            if st.button("Nueva Pregunta", type="primary"):
                grammar_text, correct_type = quiz.generate_question()
                st.session_state['current_question'] = grammar_text
                st.session_state['correct_answer'] = correct_type
                st.session_state['answered'] = False
            if 'current_question' in st.session_state:
                st.subheader("Clasifica la siguiente gramática:")
                st.code(st.session_state['current_question'], language="text")
                user_answer = st.radio(
                    "¿A qué tipo pertenece?",
                    [0, 1, 2, 3],
                    format_func=lambda x: f"Tipo {x}: " + [
                        "Rec. Enumerable", "Sensible al Contexto", "Libre de Contexto", "Regular"
                    ][x],
                    disabled=st.session_state.get('answered', False)
                )
                if st.button("Verificar Respuesta", disabled=st.session_state.get('answered', False)):
                    try:
                        correct, feedback, result = quiz.check_answer(
                            st.session_state['current_question'],
                            user_answer,
                            start_symbol
                        )
                        st.session_state['answered'] = True
                        st.session_state.quiz_total += 1
                        if correct:
                            st.session_state.quiz_score += 1
                            st.success(feedback)
                        else:
                            st.error(feedback)
                        with st.expander("Ver explicación completa"):
                            st.info(result.justification)
                            for d in result.detailed_analysis:
                                st.markdown(d)
                    except Exception as e:
                        st.error(f"Error en la verificación: {e}")
            else:
                st.info("Haz clic en 'Nueva Pregunta' para comenzar")
        if st.button("Reiniciar Puntuación"):
            st.session_state.quiz_score = 0
            st.session_state.quiz_total = 0
            st.rerun()

    # ---------------- Convertidor Regex/AFN/AFD ----------------
    elif mode == "Convertidor Regex/AFN/AFD":
        st.header("Regex → AFN → AFD → Gramática Regular (y AFD → Regex)")
        regex = st.text_input("Expresión regular:", value="(a|b)*abb")
        c1, c2, c3, c4 = st.columns(4)
        if c1.button("Construir AFN (Thompson)", type="primary"):
            try:
                nfa = regex_to_afn(regex)
                st.session_state['nfa'] = nfa
                st.success("AFN construido (estructura interna en memoria).")
                st.json({
                    "start": nfa.start,
                    "finals": sorted(list(nfa.finals)),
                    "alphabet": sorted({a for m in nfa.transitions.values() for a in m if a != 'ε'})
                })
            except Exception as e:
                st.error(f"Error: {e}")
        if c2.button("AFN → AFD (Subconjuntos)"):
            try:
                if 'nfa' not in st.session_state:
                    st.warning("Primero construye el AFN.")
                else:
                    dfa = afn_to_afd(st.session_state['nfa'])
                    st.session_state['dfa'] = dfa
                    st.success("AFD construido.")
                    st.json({
                        "start": dfa.start,
                        "finals": sorted(list(dfa.finals)),
                        "transitions": dfa.transitions
                    })
                    dot = GrammarVisualizer.create_automaton_dfa(dfa.transitions, dfa.start, dfa.finals)
                    st.graphviz_chart(dot)
            except Exception as e:
                st.error(f"Error: {e}")
        if c3.button("AFD → Gramática Regular"):
            try:
                if 'dfa' not in st.session_state:
                    st.warning("Primero genera el AFD.")
                else:
                    g = afd_to_regular_grammar(st.session_state['dfa'])
                    st.code(str(g), language="text")
            except Exception as e:
                st.error(f"Error: {e}")
        if c4.button("AFD → Regex"):
            try:
                if 'dfa' not in st.session_state:
                    st.warning("Primero genera el AFD.")
                else:
                    regex_res = dfa_to_regex(st.session_state['dfa'])
                    st.code(regex_res, language="text")
            except Exception as e:
                st.error(f"Error: {e}")

    # ---------------- CFG → PDA ----------------
    elif mode == "CFG→PDA":
        st.header("Conversión de GLC a Autómata con Pila (PDA)")
        start_symbol = st.text_input("Símbolo inicial:", value="S", key="cfgpdaS")
        gtext = st.text_area("Gramática (GLC):", height=200, value="S → aSb | ab")
        if st.button("Construir PDA", type="primary"):
            try:
                G = GrammarParser.parse(gtext, start_symbol=start_symbol)
                pda = cfg_to_pda(G)
                st.session_state['pda'] = pda
                st.success("PDA construido (aceptación por pila vacía).")
                st.json(pda)
                dot = GrammarVisualizer.create_pda_graph(pda)
                st.graphviz_chart(dot)
            except Exception as e:
                st.error(f"Error: {e}")

    # ---------------- AFD → Gramática ----------------
    elif mode == "AFD→Gramática":
        st.header("Pega un AFD en JSON y conviértelo a Gramática Regular")
        sample = {
            "states": ["q0", "q1"],
            "alphabet": ["a", "b"],
            "start": "q0",
            "accepting": ["q1"],
            "transitions": {"q0": {"a": "q1"}, "q1": {"a": "q1", "b": "q1"}}
        }
        st.code(json.dumps(sample, indent=2))
        txt = st.text_area("AFD (JSON):", height=200)
        if st.button("Convertir a Gramática", type="primary"):
            try:
                data = json.loads(txt)
                dfa = AFD(start=data["start"], finals=set(data["accepting"]), transitions=data["transitions"])
                g = afd_to_regular_grammar(dfa)
                st.code(str(g), language="text")
            except Exception as e:
                st.error(f"Error: {e}")

    # ---------------- Autómatas JSON ----------------
    elif mode == "Autómatas JSON":
        st.header("Ingesta y clasificación de autómatas")
        st.markdown("Pega JSON de **AFD** / **AP** / **MT**. Se validan campos mínimos.")
        txt = st.text_area("JSON del autómata:", height=240)
        if st.button("Analizar JSON", type="primary"):
            try:
                t, name, dot, note = classify_automaton_json(txt)
                st.markdown(
                    f'<div class="type-box type-{t}">Tipo {t}: {name}</div>',
                    unsafe_allow_html=True
                )
                st.info(note)
                if dot is not None:
                    st.subheader("Diagrama")
                    st.graphviz_chart(dot)
            except Exception as e:
                st.error(f"Error analizando JSON: {e}")

    # ---------------- Árbol de derivación ----------------
    elif mode == "Árbol de derivación":
        st.header("Árbol de derivación (NetworkX + Graphviz)")
        start_symbol = st.text_input("Símbolo inicial:", value="S", key="derivS")
        gtext = st.text_area("Gramática:", height=200, value="S → aSb | ab")
        target = st.text_input("Cadena objetivo (por ejemplo 'aabb'):", value="aabb")
        max_steps = st.slider("Profundidad máxima de derivación:", min_value=1, max_value=15, value=8)
        if st.button("Construir árbol de derivación", type="primary"):
            try:
                G = GrammarParser.parse(gtext, start_symbol=start_symbol)
                dt_builder = DerivationTreeBuilder()
                nx_tree, success_node = dt_builder.build_leftmost_derivation_tree(
                    G, target, max_steps=max_steps
                )
                if nx_tree.number_of_nodes() == 0:
                    st.warning("No se pudo construir ningún árbol de derivación.")
                else:
                    dot = DerivationTreeVisualizer.nx_to_graphviz(nx_tree, highlight_node=success_node)
                    st.graphviz_chart(dot)
                    if success_node is not None:
                        st.success("Se encontró una derivación que genera la cadena objetivo (nodo final resaltado).")
                    else:
                        st.warning(
                            "No se encontró ninguna derivación exacta para la cadena objetivo dentro de los límites establecidos."
                        )
            except Exception as e:
                st.error(f"Error al construir el árbol de derivación: {e}")

    # ---------------- Info ----------------
    elif mode == "Info":
        st.header("Jerarquía de Chomsky")
        try:
            df = pd.DataFrame({
                "Tipo": ["0", "1", "2", "3"],
                "Nombre": ["Rec. Enumerable", "Sensible al Contexto", "Libre de Contexto", "Regular"],
                "Restricciones": [
                    "Sin restricciones (α→β)",
                    "|α|≤|β|; S→ε si S no en RHS",
                    "A→β (LHS 1 variable)",
                    "A→aB o A→a (o Ba) + S→ε cond."
                ],
                "Máquina": ["MT", "LBA", "AP", "AFD/AFN"]
            })
            st.dataframe(df, use_container_width=True, hide_index=True)
            st.subheader("Notas")
            st.markdown(
                "- El comparador es **heurístico**: genera cadenas y derivaciones hasta longitud *n*.\n"
                "- Regex soporta `|`, concatenación implícita y `*` (Kleene).\n"
                "- El árbol de derivación usa NetworkX internamente y se visualiza con Graphviz."
            )
        except Exception as e:
            st.error(f"Error cargando información: {e}")

    # ---------------- Comparar ----------------
    if mode == "Comparar":
        st.header("Comparar dos gramáticas (lenguajes hasta longitud n)")
        colA, colB = st.columns(2)
        with colA:
            startA = st.text_input("Símbolo inicial G1:", value="S", key="startA")
            g1 = st.text_area("Gramática 1", height=180, value="S → aS | b")
        with colB:
            startB = st.text_input("Símbolo inicial G2:", value="S", key="startB")
            g2 = st.text_area("Gramática 2", height=180, value="S → aS | b")
        n = st.number_input("Longitud máxima (n):", min_value=0, max_value=20, value=6, step=1)
        if st.button("Comparar", type="primary"):
            try:
                G1 = GrammarParser.parse(g1, start_symbol=startA)
                G2 = GrammarParser.parse(g2, start_symbol=startB)
                inter, only1, only2 = compare_grammars(G1, G2, int(n))
                st.success("Comparación completada (BFS acotado sobre derivaciones).")
                c1, c2, c3 = st.columns(3)
                with c1:
                    st.write("**Intersección**")
                    st.code("\n".join(sorted(inter)) or "∅")
                with c2:
                    st.write("**Solo G1**")
                    st.code("\n".join(sorted(only1)) or "∅")
                with c3:
                    st.write("**Solo G2**")
                    st.code("\n".join(sorted(only2)) or "∅")
                st.write(
                    f"|L(G1)|={len(inter) + len(only1)}, |L(G2)|={len(inter) + len(only2)}, "
                    f"intersección={len(inter)} (hasta longitud {n})"
                )
            except Exception as e:
                st.error(f"Error en comparación: {e}")

    st.divider()
    st.markdown(
        """<div style='text-align: center; color: #7f8c8d;'>
        <p>Chomsky Classifier AI | Proyecto de Lenguajes Formales y Autómatas</p>
        <p>Clasificación + Regex→AFN→AFD⇄Regex + CFG→PDA + Autómatas JSON + Árboles de derivación</p>
    </div>""",
        unsafe_allow_html=True
    )


# ============================================================================
# ENTRYPOINT
# ============================================================================

if __name__ == "__main__":
    main()
